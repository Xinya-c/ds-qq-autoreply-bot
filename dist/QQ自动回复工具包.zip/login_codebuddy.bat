@echo off
setlocal
chcp 65001 >nul
title CodeBuddy CLI Login
set "SERVER__PORT="
set "SERVER__HOST="
set "CODEBUDDY_CONFIG_DIR=%USERPROFILE%\.codebuddy"
if not exist "%CODEBUDDY_CONFIG_DIR%" mkdir "%CODEBUDDY_CONFIG_DIR%"

echo ============================================================
echo  CodeBuddy CLI - Login
echo ============================================================
echo  Step 1: choose  Log in via Chinese Site  and press Enter
echo  Step 2: finish authorization in the browser
echo  Step 3: come back here and close this window
echo ============================================================
echo.
if not exist "E:\nodejs\node.exe" (
  echo [ERROR] node.exe not found
  goto :done
)
if not exist "E:\AI\codebuddy-cli\node_modules\@tencent-ai\codebuddy-code\bin\codebuddy" (
  echo [ERROR] codebuddy entry not found
  goto :done
)
"E:\nodejs\node.exe" "E:\AI\codebuddy-cli\node_modules\@tencent-ai\codebuddy-code\bin\codebuddy" %*
echo.
echo [CLI exited, code %ERRORLEVEL%]

:done
echo.
pause
