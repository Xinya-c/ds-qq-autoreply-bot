QQ 自动回复工具包
================================================

包含：守护进程、记忆模块、MCP 服务、账号管理、控制面板、一键启动脚本、
      表情包清单、项目总结文档、回归测试脚本。

使用方法
1) 安装 NapCat（本包不含），把 OneBot 正向 WebSocket 开在 127.0.0.1:3001
2) 复制 tools/qq_autoreply_config.sample.json 为 qq_autoreply_config.json，
   填入白名单与 API Key
3) 安装依赖：python-docx、Pillow、pypdf
4)（可选）安装 CodeBuddy CLI 并登录，用于 codebuddy_cli 后端；
   也可装 sentence-transformers 启用语义检索（memory_vector）
5) 双击 一键启动.bat

回归测试（可选，跑一下确认环境正常）
  python tools/e2e_smoke.py        # 端到端冒烟，127 项
  python tools/golden_prompt.py    # 提示词拼装基线
  python tools/proactive_replay.py # 群聊主动接话回放

注意
- 本包不含聊天记录、图片、日志、API Key。
- 表情包图片未包含（体积与授权原因），仅含 stickers.json 清单；
  需要时把图片放进 assets/replies/ 即可，文件名与清单对应。
- .bat 文件必须是 ASCII + CRLF，否则 cmd 会解析失败（这是踩过的坑）。
- config 里的 owner_qq 填主人的 QQ 号，机器人据此判断「谁说话才算数」；
  留空则不启用这个判断。
